/*****************************************************
 *  Project: Programable Electronic Load (ESP32 Based)
 *  Firmware Version: REV_1.0_INDEV
 *  File: Declarations.h
 *  Author: Gopinath.G
 *  Release Date: Oct-2025
 *  Contact information:query.gopi@gmail.com
 *  Description: Core definitions, pin mapping, and 
 *               global variables for system control.
 *****************************************************/

#define FIRMWARE_VERSION "REV_1.0_INDEV"   // Firmware revision info for display/debug

/********************** TFT Display Pins **********************/
#define TFT_CS    5     // Chip Select for TFT
#define TFT_RST   26    // Reset pin for TFT
#define TFT_DC    27    // Data/Command select pin

/********************** Input/Output Pins **********************/
#define NTC_Pin       36   // Analog input pin for NTC temperature sensor
#define Relay         19   // Relay output pin to enable/disable load
#define reverse_detc  2    // Reverse polarity detection pin (interrupt input)
#define Fan_PIN       15   // Cooling fan control output
#define MOS_PIN       4    // MOSFET gate drive pin for load control
#define Buzzer_pin    17   // Buzzer output for alerts/warnings

/********************** Buzzer Tune **********************/
// Simple startup melody (C–G–G–A–G–B–C)
const int melody[] = {
  262, 196, 196, 220, 196, 0, 247, 262
};

// Duration for each note (quarter, eighth, etc.)
const int noteDurations[] = {
  4, 8, 8, 4, 4, 4, 4, 4
};

/********************** Measured Values **********************/
float rawVoltage;   // Instantaneous measured voltage
float rawCurrent;   // Instantaneous measured current
float rawPower;     // Instantaneous measured power

/********************** PID Constants **********************/
// Used for closed-loop load control
float Kp = 70;      // Proportional gain
float Ki = 1.1;     // Integral gain
float Kd = 0;       // Derivative gain (unused for now)
float al = 0.03;    // Alpha for exponential moving average (filter strength)

/********************** NTC Thermistor Parameters **********************/
// Used to calculate temperature from analog reading
const float R_FIXED = 100000.0;  // Reference resistor in voltage divider (100kΩ)
const float BETA = 3950.0;       // Beta constant for MF52 thermistor
const float R0 = 100000.0;       // Resistance at 25°C (100kΩ)
const float T_ref = 298.15;      // Reference temperature (Kelvin) = 25°C

#define NUM_SAMPLES 5            // Number of samples for temperature averaging
#define SAMPLE_INTERVAL 100      // Sampling interval (ms)
#define over_temp_threshold 130  // Overtemperature protection limit (°C), IRFZ44N has Junction temperature limit of 150C for safer operation it is limited to 130C
bool over_temp_flag;             // True when overtemperature detected
#define MOS_Rjc 1.5              // IRFZ44N Mosfet junction to case thermal resistance 


/********************** PID Loop Timing **********************/
unsigned long lastPIDTime = 0;             // Timestamp for last PID loop run
const unsigned long pidInterval = 10;      // PID execution interval (10ms)

/********************** Status Flags **********************/
bool load_status_flag = 0;       // Load ON/OFF state
bool reverse_V_flag = 0;         // Reverse polarity status flag
bool reverse_warning_shown = false;  // To prevent multiple warnings on display
bool temp_warning_shown = false;     // Same for temperature warning
bool reverseDetected = false;        // True when reverse polarity is detected
bool reverseTriggered = false;       // Used to control reverse detection timing

/********************** Keypad Setup **********************/
const byte ROWS = 4;             // 4 rows
const byte COLS = 4;             // 4 columns

// ESP32 supports only input on certain GPIOs (so rows = input only)
byte rowPins[ROWS] = {39, 34, 35, 32};   // Row input pins
byte colPins[COLS] = {33, 25, 12, 13};   // Column output pins

// Key mapping layout
char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

/********************** Parameter Struct **********************/
// Used to hold live measurements and settings
struct myparam {
   float voltage;     // Measured voltage
   float current;     // Measured current
   float power;       // Calculated power
   String setpoint;   // Current setpoint as string (user input)
   float NTC_temp;    // Temperature in °C
   uint8_t duty;      // PWM duty cycle applied for FAN
} param;

/********************** Change Detection **********************/
// Used to avoid unnecessary display updates
float lastVoltage = -1;
float lastCurrent = -1;
float lastPower = -1;
float lastTemp = -100;
int lastDuty = -1;

/********************** Safe Operating Limits **********************
The below values are limited for safe operations the INA260 can handle Voltage of 36V input and current of 15A 
 ******************************************************/
// Maximum allowable values for user inputs
enum MaxValues {
  voltage = 30,   // Max 30V input
  current = 10,   // Max 10A load
  power   = 100   // Max 100W total power
};

/********************** Operating Mode **********************/
// Supported operation modes for load
enum Mode { CC, CV, CW, CR };   // Constant Current, Voltage, Power, Resistance
Mode currentMode = CC;          // Default mode: Constant Current

/********************** Timer Variables **********************/
bool timerRunning = false;      // True when load timer is active
unsigned long startTime = 0;    // Start time for timer
unsigned long elapsedTime = 0;  // Elapsed time since start

// Used to track changes for display updates
bool lastTimerRunning = false;
String lastSetpoint = "";
int lastMode = -1;

/********************** Filtered Measurements **********************/
// Filtered (smoothed) versions of sensor readings
float filteredVoltage = 0;
float filteredCurrent = 0;
float filteredPower = 0;

/********************** Time Counters **********************/
int hours;     // Hours since load ON
int minutes;   // Minutes since load ON
int seconds;   // Seconds since load ON
